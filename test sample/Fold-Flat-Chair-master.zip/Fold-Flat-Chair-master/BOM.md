I purchased 2" hinges for the prototype, however the next version will use 3" hinges to be more durable
