# Fold Flat Chair

A flat folding chair which is easy to store


In preporation for MakerFaire I realized we needed some chairs to sit in, but rather than bring some I decided to cut some out when we get there. This design is copied from something I saw in numerous places on the internet. They cut quickly (~1hr) because of the common cut lines, and they fold compleetly flat.

This is version one of the chair, I am going to update the file based on my experance with it.

The original file is here: [OnShape](https://cad.onshape.com/documents/512dd4d4644f0b47d533aa92/w/dfb9ea0334313cd7fdf95b7e/e/59f65984aec93f847040b217)

![side view](https://raw.githubusercontent.com/MaslowCommunityGarden/Fold-Flat-Chair/master/back.jpg)

![folded flat](https://raw.githubusercontent.com/MaslowCommunityGarden/Fold-Flat-Chair/master/folded%20flat.jpg)
