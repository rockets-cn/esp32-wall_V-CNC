{
    "ModerationLevel": "communityManaged",
    "Facilitator": "barboursmith",
    "Category": "furniture" 
}
