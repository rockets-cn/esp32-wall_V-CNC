The assembly is relitively easy because all the parts are already in place.

For the next one I do I will attach the hinges before cutting the tabs holding the parts together.

Keep in mind that the seat has the hinge on the front while the pack support has the hinge on the back.
